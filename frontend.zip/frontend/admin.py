from django.contrib import admin

# Register your models here.

from frontend.models import *


admin.site.register(Slider)
admin.site.register(About)
admin.site.register(Courses)
admin.site.register(Logo)